Install: `pip install .`
